package com.example.GrievenaceManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrievenaceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
