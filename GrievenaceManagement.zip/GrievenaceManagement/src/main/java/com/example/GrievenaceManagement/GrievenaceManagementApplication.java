package com.example.GrievenaceManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrievenaceManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrievenaceManagementApplication.class, args);
	}

}
